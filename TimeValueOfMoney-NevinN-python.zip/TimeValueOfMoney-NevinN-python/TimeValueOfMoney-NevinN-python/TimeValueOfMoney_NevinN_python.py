
#TimeValueOfMoney project by Nevin Ndonwi

#import all of the elements of locale 
from locale import* 

#import math for pow() function for exponents 
from math import*


def getChoice():
    #use boolean variable for loop control..
    val = False
    while not val:
        try:
             c = int(input("Select operation: 1=PV, 2=FV, 3=FV-Annuity, 0=quit\n"))
             if c < 0 or c > 3:
                 #illegitimate input
                 print("Illegal input, (only 0,1,2,3 are valid inputs) Please try again\n")
                 
                 val = False
             else:
                 #legal input
                 val = True 

           

        except ValueError:
            print("Illegal input, (only 0,1,2,3 are valid inputs) Please try again\n")
           
            val = False

    #returns user input to the main function
    return c






#Extra credit (amount, term and rate are all obtained from the same function (getNum))

def getNum(prompt,type): #gets two arguements, the prompt and the type of value that is being returned 
    if type == "i": #if this function need to return an integer
        
    #used to return an integer greater than 0
        while True:
            try:
                term = int(input(prompt))

                if term > 0:
                    break
                else:
                    print("Illegal input, Input a number above 0\n")
            except:
                print("Illegal input, (please input a number (without decimal points) above 0) Please try again\n")

        return term 



    elif type == "f":#if this function needs to return a float (decimal)
        #must be 'robust' - with loop and try except
            while True:
               try:
                   v = float(input(prompt))
                   
                   if v > 0:
                      break
                   else:
                      print("Illegal input, Input a number above 0\n")
               except:
                   print("Illegal input, (please input a number above 0) Please try again\n")
            

    #return must be a positive float greater than 0
            return v
   





def doFVA():
    
    deposit = getNum("Monthly Deposit:\n", "f")
    print("Your deposit was %s " % currency(deposit,grouping = True), "\n")


    #rates must be greater than 0 ( >0) but less than or equal to 25% (<= 25)
    rate = getNum("Get Annual Interest Rate (input 9.5 for 9.5%)\n(must be more that 0% and less than or equal to 25%) :\n", "f")
    while (rate < 0 or rate > 25):
        print("Invalid input for the rate, try again\n")
        #rates must be greater than 0 ( >0) but less than or equal to 25% (<= 25)
        rate = getNum("Get Annual Interest Rate (input 9.5 for 9.5%)\n(must be more that 0% and less than or equal to 25%) :\n", "f")
    

    term = getNum("Input the term (in whole months):\n", "i") #gets the term 
    

    fva = 0 #initialization of future value variable
    fi = 0 #initialisation of future interest variable 

    #formula requires monthly interest rate but our was entered as annual rate 

    morate = (rate / 12) /100 #(converts yearly interest rate to monthly rate) (dividing by 100 converts it to percent form)

    for x in range(0,term):
        intearn = (fva + deposit) * morate #interest earned in the month
        fva = fva + deposit + intearn #adds to the future value




        #output statement 
    fi = fva - (deposit * term) 
    print("Your monthly deposit of %s" % currency(deposit,grouping = True),  "earning" , "{:.2%}".format(rate/100) , "interest annually", "after", term , "months will have a final value of: %s " % currency(fva,grouping = True) )

    print("That includes interest earned of %s" % currency(fi,grouping = True),"\n")



def doFV():
   
    deposit = getNum("Input the deposit:\n", "f")
    print("Your deposit was %s " % currency(deposit,grouping = True), "\n")


    #rates must be greater than 0 ( >0) but less than or equal to 25% (<= 25)
    rate = getNum("Get Annual Interest Rate (input 9.5 for 9.5%)\n(must be more that 0% and less than or equal to 25%) :\n", "f")
    while (rate < 0 or rate > 25):
        print("Invalid input for the rate, try again\n")
        #rates must be greater than 0 ( >0) but less than or equal to 25% (<= 25)
        rate = getNum("Get Annual Interest Rate (input 9.5 for 9.5%)\n(must be more that 0% and less than or equal to 25%) :\n", "f")
    

    term = getNum("Input the term (in whole months):\n", "i") #gets the term 
    
    fv = 0 # initializing future value variable 
    fi = 0 #initializing future interest variable
    #formula requires monthly interest rate but ours was entered as annual rate 

    morate = (rate / 12) /100 #(converts yearly interest rate to monthly rate) (dividing by 100 converts it to percent form)


    fv = deposit * ( pow((1 + morate), term)) #future value formula (utilising pow() function for exponents 

    fi = fv - deposit # this is how we get the interest 





        #output statement 
    
    print("A deposit of %s" % currency(deposit,grouping = True),  "earning" , "{:.2%}".format(rate/100) , "interest annually", "after", term , "months will have a final value of: %s " % currency(fv,grouping = True) )

    print("That includes interest earned of %s" % currency(fi,grouping = True), "in interest.\n")






    

def doPV():
   
    deposit = getNum("Input the amount to be recieved:\n", "f")
    print("Your amount to be recieved is %s " % currency(deposit,grouping = True), "\n")


    #rates must be greater than 0 ( >0) but less than or equal to 25% (<= 25)
    rate = getNum("Input Annual Interest Rate (input 9.5 for 9.5%)\n(must be more that 0% and less than or equal to 25%) :\n", "f")
    while (rate < 0 or rate > 25):
        print("Invalid input for the rate, try again\n")
        #rates must be greater than 0 ( >0) but less than or equal to 25% (<= 25)
        rate = getNum("Input Annual Interest Rate (input 9.5 for 9.5%)\n(must be more that 0% and less than or equal to 25%) :\n", "f")
    

    term = getNum("Input the term (in whole months):\n", "i") #gets the term 
    
    pv = 0 # initializing present value variable 
    d = 0 #initializing discount variable
    #formula requires monthly interest rate but ours was entered as annual rate 

    morate = (rate / 12) /100 #(converts yearly interest rate to monthly rate) (dividing by 100 converts it to percent form)


    pv = deposit/(pow(1 + morate, term)) #present value formula (utilising pow() function for exponents 

    d = pv - deposit # this is how we get the discount value 





        #output statement 
    
    print("An amount of %s" % currency(deposit,grouping = True),  "with a annual cost of money of" , "{:.2%}".format(rate/100) , "recieved in", term , "months will have a present value of: %s " % currency(pv,grouping = True) )

    print("That includes interest earned of %s" % currency(d,grouping = True))










def main():

    #checks user's location
    result = setlocale(LC_ALL, '')
    #Checks if C is the default location set
    if result == "C" or result.startswith("C/"):
         #sets user's country to US 
        setlocale(LC_ALL, 'en_US')
        
    print("Welcome to the Financial Calculator\n")
    

    choice = getChoice()

    #initializes deposit variable 
    deposit = 0

    while choice != 0:
        # get data and calculations

        #outputs the user's input
        print("Your choice was: ", choice, "\n")

        if choice == 1:
            #PV logic
            print("You have chosen PV (Calculating the Present Value)\n")
            doPV()



            
         
        elif choice == 2:
            #FV logic
            print("You have chosen FV (Calculating the Future Value)\n")
            doFV()


            

        elif choice == 3:
            #FV- annuity logic 
            print("You have chosen FV-Annuity")
            doFVA()
           

        #careful coding (incase an outside variable is input or hacked into the program)
        else:
            print("Unknown operation\n")






        #ask user for input (next operation or quit)
        choice = getChoice()
        print()

    print("Thank you for using the financial calculator!\n")


#launch program based on environment variable __name__ 
if __name__ == "__main__":
    main()



    

"""
Previous dual functions 

def getValue(prompt):
    #must be 'robust' - with loop and try except
    while True:
        try:
           v = float(input(prompt))
           if v > 0:
               break
           else:
               print("Illegal input, Input a number above 0\n")
        except:
            print("Illegal input, (please input a number above 0) Please try again\n")
            

    #return must be a positive float greater than 0
    return v



def getTerm(prompt): #extra credit (return the amount(float),  rate (float) or term(int)  ) 

    #used to return an integer greater than 0
    while True:
        try:
           term = int(input(prompt))

           if term > 0:
               break
           else:
               print("Illegal input, Input a number above 0\n")
        except:
            print("Illegal input, (please input a number (without decimal points) above 0) Please try again\n")

    return term 

    """