﻿Public Class frmintro


    Private Sub btnexit1_Click(sender As Object, e As EventArgs) Handles btnexit1.Click
        Me.Close()
    End Sub

    Private Sub frmintro_Load(sender As Object, e As EventArgs) Handles Me.Load
        Btnstartgame.BackColor = Color.Green

    End Sub

    Private Sub btnsecret_Click(sender As Object, e As EventArgs) Handles btnsecret.Click
        lblsecret.Visible = True
    End Sub
End Class
