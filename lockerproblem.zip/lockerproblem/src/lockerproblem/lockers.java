package lockerproblem;


public class lockers {

	  
	 
	public static void main(String args[]) {
		/*Team Project 3: Locker Puzzle
		*4/3/2021
		*File: LockerProject.java
		Team 5 members: Orion Strinni, Nevin, Ndonwi, Adam Johnson
		*/ 

 
		

		        boolean[] lockers = new boolean[100];

		        for (int i=1; i<=100;i++){
		        	
		        	
		           for (int j=i-1; j<100;j+=i){
		        	   
		             lockers[j] = !lockers[j];
		            // System.out.println("Locker "+lockers[j]);
		    
		           }
		           
		           
		        }
		        //print open lockers
		        for (int i=0; i<lockers.length; i++){
		            if(lockers[i]){
		                System.out.println("Locker "+(i+1)+" is open ");
		            }
		        }
		
		        
		
		/*
		A school has 100 lockers and 100 students. All lockers are closed on the first day of school. As the
students enter, the first student, denoted S1, opens every locker. Then the second student, S2, begins
with the second locker, denoted L2, and closes every other locker. Student S3 begins with the third
locker and changes every third locker (closes it if it was open, and opens it if it was closed). Student S4
begins with locker L4 and changes every fourth locker. Student S5 starts with L5 and changes every fifth
locker, and so on, until student S100 changes L100.
		*/
		
		
	}
}
