// Prog-Chal-14-c++-NevinN.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
// Programming Challenge 14 page 321
using namespace std;

// The greatest and least of these
int main()
{

	//variable initialization
	int num = 0;

	cout << "\nInput an integer: ";
	cin >> num; // gain an input

	int max = num;
	int min = num;
	
	while (true) { //infinite loop

		cout << "\nInput an integer: ";
		cin >> num; // gain an input

		
		if (num == -99) {
			break; //end sentinel , end loop
		}
		else if (num > max) { // if the number is greater than the current max variable, then update accordingly
			max = num;
		}
		else if (num < min) { // if the number is less than the current max variable, then update accordingly
			min = num;
		}
		

   }

	cout << "\n\n\nThe greatest number inputted was: " << max;
	cout << "\nThe smallest number inputted was: " << min << "\n\n";


}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
