package accountgenerator;

public class AccountGenerator {

	public static void main(String[] args) {

		Employee emp = new Employee();
		System.out.println(emp);
                

	}//end method main
}//end class AccountGenerator
  