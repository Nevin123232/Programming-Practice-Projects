// chapter4-pchal8-NevinN.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>


//Programming Challenge 8 page 241

//Math tutor version 2 


using namespace std;

int main()
{

    // initialization of variables 
    int num1 = rand() % 40 + 10;
    int num2 = rand() % 40 + 10;
    int answer = 0;
    int attempt = 0;

    answer = num1 + num2;


    cout << "Input the answer to " << num1 << " + " << num2 << ":\n";
    cin >> attempt;
    

    if (attempt == answer) {


        cout << "Congradulations, You got the correct answer!\n";
    }
    else {


        cout << "You did not get the correct answer\n";
        cout << num1 << " + " << num2 << " = " << answer;

    }
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
