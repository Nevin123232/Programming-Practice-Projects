
import javax.swing.JFrame;

public class CalcMain {
    public static void main(String [] args)
    {
JFrame frame = new JFrame("Calculator");
//2. Optional: What happens when the frame closes?
/*
 * 
 * The project closes
 */
frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//3. Create your panel and put it in the frame.
frame.getContentPane().add(new Calculator());
//4. Size the frame.
frame.setSize(300, 550);
//5. Show it.
frame.setVisible(true);
           }
    
}
 