from tkinter import * 

root = Tk() 

#title of application
root.title("Calculator")



e = Entry(root, width = 50, borderwidth= 5)

e.grid(row = 0, column = 0, columnspan = 4, padx = 10, pady = 10)

#these are the buttons with numbers 0,1,2,3,4,5,6,7,8,9

button0 = Button(root, text = "0", padx = 50)
button0.grid(row = 1, column = 0, columnspan = 1, padx = 0, pady = 0)

'''
button1 = Button(root, text = "1", padx = 50)
button1.pack()

button2 = Button(root, text = "2", padx = 50)
button2.pack()

button3 = Button(root, text = "3", padx = 50)
button3.pack()

button4 = Button(root, text = "4", padx = 50)
button4.pack()

button5 = Button(root, text = "5", padx = 50)
button5.pack()

button6 = Button(root, text = "6", padx = 50)
button6.pack()

button7 = Button(root, text = "7", padx = 50)
button7.pack()

button8 = Button(root, text = "8", padx = 50)
button8.pack()

button9 = Button(root, text = "9", padx = 50)
button9.pack()

'''


#buttons with all of the operations (*, / , + , - , %, ^)





#makes it keep existing until it closes
root.mainloop()