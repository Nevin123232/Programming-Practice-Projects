package passengerfare;

import java.util.Scanner;

// This is the  passenger fare look up problem:


public class passenger {

	/*
	psuedocode/ flowchart:
	
	1: Find array data (convert it into a 2d array)
	
	2: gain inputs (the amount of passengers and the timezones)
	
	3: Check the inputs and return if they work or not
	
	4: display the fare
	 
	
	 
	 */

	
	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in); // creating a scanner
		
		// Array of passengers and timezones charges
		
		double[][] graph = { {7.5, 10.0,12.0, 12.75 } /* first row (one passengers) */ , 
				{14.0, 18.5, 22.0, 23.0,   } /* second row (two passengers ) */, 
				{20.0, 21.0, 32.0, 33.0 },/* third row (three passengers) */ 
				{25.0, 27.5, 36.0, 37.0,  }/* fourth row (four passengers) */ };
		
		String pax = ""; // String input
		int pa = -1;
		System.out.println("Input the amount of passengers you have: ");
	
		//gain bedrooms
		 pax = scan.nextLine();	
	    
	    // check if the bedrooms are inputted correctly 
	    while(  !(  (pax.equals("1")) ||  (pax.equals("2")) ||  (pax.equals("3")) ||  (pax.equals("4"))  )  ) {
	    
	    		
	      
	    		
	    	

	    	System.out.println("Your previous input was invalid (Input a number) "); // if user doesn't input a number
	    	    
	    	
	    	System.out.println("Possible amounts of passengers include: (Input 1,2,3, or 4) "); // if user inputs a number that isnt 1-4
	    	
	    	 pax = scan.nextLine();	
	    
	    }
		
	    pa = Integer.parseInt(pax);
	    pa -= 1;
	    
		String zone = "";
		
		System.out.println("\nInput the timezone: ");
		
		  zone = scan.nextLine();
		
        while( !(  (zone.equals("A")) ||  (zone.equals("B")) ||  (zone.equals("C")) ||  (zone.equals("D"))  )  ) {
	    	
	    	
	    	  
	    	    System.out.println("\nYour previous was invalid \n");
	    		System.out.println("\nPossible timezones include: (Input A, B, C, or D) ");
	    		  zone = scan.nextLine();
	    
	    }
		
		int o = -1;
			if( (zone.equals("A"))) {
			o = 0;
	  
	 
						}
			 else if( (zone.equals("B"))) {
				 
				 o = 1;
				 
			 }
			 else if( (zone.equals("C"))) {
				 
				 
				 o = 2;
			}
			 else if( (zone.equals("D"))) {
				 
				 o = 3;
				 
			}
	 
        System.out.println("\n\n*******\n\n");
        System.out.println("\nYour fare has been found\n");
		
		System.out.println("Here is your fare for these requirements: " + graph[pa][o]);
		
		
		scan.close();
	}
	
	
}

