// NevinNdonwiPChal1.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>

using namespace std;

int main()
{
	// Candy bar sales
	double amount; // amount of candy bars sold
	double bar; //amount of money earned per candy bar
	double total; //total amount of money earned per candy bar

	cout << "Please input the amount of candy bars sold\n";

	cin >> amount;

	cout << "Please input the amount of money earned per candy bar (in dollars)\n";

	cin >> bar;

	total = amount * bar;// total variable is given the value of the amount of money the candy bar sale made 

	

	cout << "\nHere is the total amount of revenue earned: " << total;


}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
