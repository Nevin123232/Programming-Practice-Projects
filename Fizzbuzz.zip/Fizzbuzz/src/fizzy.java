
import java.util.*;


public class fizzy {

	static Scanner scan = new Scanner(System.in);
	
	
	
	public static boolean numberLegitimizer(String test) {
		
		 
		boolean legit = false;
		String numbers = "1234567890";
	
		int counter = 0;  
		
		for (int i = 1; i <= test.length(); i++) { // Checks if any of the number characters does not equal a number character
			
			
			for (int o = 1; o <= numbers.length(); o++) {
			
			  if(test.substring(i - 1,i).equals(numbers.substring(o - 1, o)) ) {
				
				counter += 1; 
				break;
			   }
			  
			 
			  
			  
				
			}
			
		}
		
		
		if (counter >= test.length() ) {   // checks if the amount of legitimate number characters is greater than or equal to the length of the string

			

			return !legit; // Returns true if it doesn't contain a non-number character
			
			// returns true if the amount of legitimate number characters is greater than or equal to the length of the string 
		}
		else {
			
		return legit; // Returns false if it does contain a non-number character
		
		// returns false if the amount of legitimate number characters is less than the length of the string 
		}
		
		
		
	}
	public static void main(String[] args) {
	
		// Selection sort array practice
		// still a prototype lol 
		
		ArrayList<Integer> oof = new ArrayList<Integer>();
		
		System.out.println("Input some numbers so that we can sort and outut them from least to greatest!!! \n");
		
		int oofo = 0;
		 boolean ooo = true;
		 
		 String bruh = "";
		 
		 
		while(ooo == true) {
			
			System.out.println("Input a number, Input 'y' when you want to stop inputting numbers");
			
			bruh = scan.nextLine();
			
			if(bruh.equals("y")) {
				
				
				break;
			}
			else if( numberLegitimizer(bruh) == true ) {
				oofo = Integer.parseInt(bruh);
				oof.add(oofo);
				
			}
			else {
				
				
				System.out.println("Input a legit number lol \n");
			}
			
			
			
		}
		
		
		
		System.out.println(oof);
		
		int temp = 0;
		int temp2 = 0;
		
		
		for(int i = 1; i < oof.size(); i++) {
			
			if(oof.get(i - 1) > oof.get(i)) {
				
				temp = oof.get(i - 1); 
				temp2 = oof.get(i);
			   oof.set(i - 1,temp2 );
				oof.set(i, temp);
				
				
				// selection sort with array list 
			}
			else if( (oof.get(i - 1) < oof.get(i)) ) {
				
				
				
				temp2 = oof.get(i - 1); 
				temp = oof.get(i);
			   oof.set(i - 1,temp2 );
				oof.set(i, temp);
				
				
				
				
			}
			
			
			
		}
		
		System.out.println(oof);
		
		/*
		 * Fizzbuzz assignment
		for(int o = 1; o < 101; o++ ) {
			
			if((o % 3 == 0) && (o % 5 == 0) ) {
				
				System.out.println("FizzBuzz");
				
			}
			else if(o % 3 == 0) {
				
				System.out.println("Fizz" );
		
			}
			else if (o % 5 == 0) {
				
				
				System.out.println("Buzz");
				
			}
			else {
				
				
				System.out.println(o);
			}
			
			
			
			
		}
		
		*/
		
	
	}
}
