

// This is the rent look up table problem
 
import java.util.*;

public class array1 {

	/* 
	psuedocode/ flowchart:
	
	1: Find array data (convert it into a 2d array)
	
	2: gain inputs (the bedroom amount and floor number)
	
	3: Check the inputs and return if they work or not
	
	4: display the monthly charges
	
	
	 
	 */
	
	
	
	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in); // creating a scanner
		
		// Array of bedrooms and rent charges
		
		int[][] rent = { {350, 400,475, 600, 1000 } /* first row (one bedroom) */ , 
				{390, 440, 530, 650, 1075  } /* second row (two bedroom) */, 
				{435, 480, 575, 700, 1150 } /* third row (three bedroom) */ };
		
		int bedrooms = 0;
		System.out.println("Input the amount of bedrooms you are searching for: ");
	
		//gain bedrooms
	   
	    
		
	    // check if the bedrooms are inputted correctly 
		
		String prebed = "";
		 prebed = scan.nextLine();
	    while( !(  (prebed.equals("1")) ||  (prebed.equals("2")) ||  (prebed.equals("3"))  )   ) {
	    	
	    	
	    		System.out.println("Your previous input was invalid (Input a number) "); // if user doesn't input a number
	    	    
	    		 
	    		
	    	
	    	
	    	
	    	System.out.println("Possible bedrooms include: (Input 1,2, or 3) "); // if user inputs a number that isnt 1-5
	    	
	    	 prebed = scan.nextLine();
	    
	    }
		
	    bedrooms = Integer.parseInt(prebed);
	    
	    
	    bedrooms -= 1;
	    
		int floornumber = 0;
		
		System.out.println("\nInput the floor number: ");
		
		String prefloor = "";
		prefloor = scan.nextLine();
        while(  !(  (prefloor.equals("1")) ||  (prefloor.equals("2")) ||  (prefloor.equals("3")) ||  (prefloor.equals("4")) ||  (prefloor.equals("5")) )   ) {
	    	
	    	

    		
    	
	    	
	    	
        
    
		    		System.out.println("Your previous input was invalid  (Input a number)");
		    		

		    		System.out.println("Possible floor numbers include: (Input 1,2,3,4, or 5) ");
		    		prefloor = scan.nextLine();
		    	    
	    }
		
        floornumber = Integer.parseInt(prefloor);
        floornumber -= 1;
	 
        System.out.println("\n\n*******\n\n");
        System.out.println("\nYour rent has been found\n");
		
		System.out.println("Here is your rent for this listing: " + rent[bedrooms][floornumber]);
		
		
		scan.close();
	}
	
	

}

