import java.util.*; // java.util.ArrayList

public class arraylist {
	
	public static void main(String[] args) {  // don't forget this 

		
		
		
	ArrayList pokemonteam1 = new ArrayList(); // player 1 team (can have 1 - 3 pokemon)
	ArrayList pokemonteam2 = new ArrayList(); // player 2 team (can have 1 to 3 pokemon)
	
	
	String[] possiblepokemon = {"metagross", "gliscor", "excadrill", "arcanine", "krookodile", "feraligatr", "gyarados", "starmie", "gengar", "espeon", "jolteon", "glaceon", "archeops", "umbreon", "leafeon", "vaporeon", "flareon", "sylveon", "scizor", "hydreigon", "meloetta"};
	String[] abbreviated = {"met", "gli", "exc" , "arc" , "kro" , "fer", "gya", "sta" , "gen" , "esp", "jol", "gla", "arch", "umb", "lea", "vap", "fla", "syl", "sci", "hyd", "mel"};
	// 21 pokemon are in the possible pokemon array 
	Scanner teambuilder = new Scanner(System.in); // the name of my scanner that I use for user input 
	// teambuilder.nextLine(); (reads the input) 
	
	System.out.println(" \nTime to initialize your pokemon team player 1! \n "); 
	
	System.out.println("\n How many pokemon do you want on your team? Minimum: 1, Maximum 3 "); // using length property of possible pokemon array
	
    String rick = teambuilder.nextLine();

    boolean oofo = true;
    
    while(oofo == true) {
    	
    	if(  rick.equals("1") ) {
    		
    		break;
    		
    	}
    	else if(  rick.equals("2") ) {
    		
    		break;
    		
    	}
    	else if(  rick.equals("3") ) {
    		
    		break;
    		
    	}
    	else
    		System.out.println("Input 1, 2 or 3");
    		rick = teambuilder.nextLine();
    	
    	
    }
 
    int amount = Integer.parseInt(rick);
    
    String oof = new String();
    
	for(int i = 0; i < amount ; i++) {
		
		System.out.println("\n Input a team member player 1 (Input the abbreviated letters next to the pokemon that you want)\n");
		
		// print the pokemon and abbreviations
		System.out.println("\n These are your options \n");
		
		for(int j = 0; j < possiblepokemon.length; j++) {
			
			
			
			System.out.println(" - " + possiblepokemon[j] + "   " + abbreviated[j] + "  " + "\n");
			
		}
		
		System.out.println("\n Input the abbreviated name of the pokemon (for example; if you would like to use metagross then input 'met' (without quotes) ");
		// outputs possible pokemon and their abbreviations 
		
		
		 oof = teambuilder.nextLine();
		 
		 for(int k = 0; k < amount; k++) {
			 
			 if (oof == abbreviated[k]) {
				 
				 oof = possiblepokemon[k];
				 
			 }
			 
			 
		 }
		
		 pokemonteam1.add(oof);
	   
		
	}
		
	
	
	
		
		
		
		
	
	
	System.out.println(pokemonteam1);
	System.out.println(" \n Player 1's team has " + pokemonteam1.size() + " member(s) \n");
	
	
	teambuilder.close(); 
	
	
	}
}
