
import java.util.Scanner; 


public class hello {
	
	
	public static void main(String[] args) {
		
		 
		
		Scanner scan = new Scanner(System.in); // opens the scanner (allows user input )
		
		
		// TODO Auto-generated method stub
        // oooh first java project 
		
		 System.out.println("Hello world \n");
	      
	     
	     System.out.println("\n This will make a party of pokemon \n");
	     System.out.println("\n Input pokemon 1 \n");
	     
	     String pokemon1 = scan.nextLine();
	     
         System.out.println("\n Input pokemon 2 \n");
	     
	     String pokemon2 = scan.nextLine();
	     
         System.out.println("\n Input pokemon 3 \n");
	     
	     String pokemon3 = scan.nextLine();
	     
         System.out.println("\n Input pokemon 4 \n");
	     
	     String pokemon4 = scan.nextLine();
	     
         System.out.println("\n Input pokemon 5 \n");
	     
	     String pokemon5 = scan.nextLine();
	     
         System.out.println("\n Input pokemon 6 \n");
	     
	     String pokemon6 = scan.nextLine();
	     
	     
	     String team[] = {pokemon1, pokemon2, pokemon3, pokemon4, pokemon5, pokemon6};
	     
	     
	     
	     for (int i = 5; i > 2; i--) { // is supposed to output the pokemon team backwards
	    	 
	    	int rick = i + 1;
	    	 System.out.println("\n Your " + (rick) + "th " + " pokemon " + " is " + team[i]);
	     }
	     System.out.println("\n Your 3rd pokemon is " + team[2]);
	     System.out.println("\n Your 2nd pokemon is " + team[1]);
	     System.out.println("\n Your 1st pokemon is " + team[0]);
	     scan.close();
	     // closes scanner 
	     
	     
	     
	     
	     
	     
	}

}
