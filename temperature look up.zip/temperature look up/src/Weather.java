
import java.util.*;
 

// This is the temperature look up problem

public class Weather {

	/*
	psuedocode/ flowchart:
	
	1: Find array data (convert it into a 2d array)
	
	2: gain inputs (the temperature in farenheit and the wind velocity)
	
	3: Check the inputs and return if they work or not
	
	4: display the wind chill factor
	 
	
	 
	 */
	
	static Scanner scan = new Scanner(System.in);
	
	public static void main(String args[]) {
		
		boolean useagain = true;
		String use = ""; // The user will input n into this variable if they want to quit
		
		
		// Arrays of windchill factors based on temperature
		
		/* -20 */  int[] neg20 = { -26,-46,-58,-67,-74,-79  } ;
		/* -15 */  int[] neg15 = { -21,-40,-51,-60,-66,-71  } ;
		/* -10 */  int[] neg10 = { -15,-34,-45,-53,-59,-64  } ;
		/* -5 */   int[] neg5 = { -10, -27,-38, -46,-51,-56   } ;
		/* 0 */    int[] zero = {-5,-22,-31, -39,-44,-49  } ;
		/* 5 */    int[] pos5 = { 0,-15,-25,-31,-36,-41  } ;
		/* 10 */   int[] pos10 = { 7, -9 , -18, -24, -29, -33  } ;
		/* 15 */   int[] pos15 = {12, -3, -11, -17, -22, -25   } ;
		
		
		
		// The wind velocity is going to stand for the position of the array. the formula will be   [ (Wind velocity / 5) - 1 ]. 
		// This will result in the array positions 
		// For example (Wind velocity of 5 miles per hour)  5/5 = 1, 1-1 = 0, the array position of all of the wind chills with 5 mile per hour wind is 0. 
		//  For example (Wind velocity of 20 miles per hour)  20/5 = 4, 4-1 = 3, the array position of all of the wind chills with 20 mile per hour wind is 3. 
		
		while(useagain) { // If the user wants to stay in the application
			
			
			
			
			System.out.println("Input the temperature: ");
			
			boolean correct = false; // controls temperature while loop
			String temp = "";
			
			temp = scan.nextLine();
			
			//Gain the temperature
			while( !(correct) ) {
				
				
				// Acceptable inputs
				 if(temp.equals("-20")) {
					
					correct = true;
				}
				else if(temp.equals("-15")) {
									
					correct = true;
				}
				else if(temp.equals("-10")) {
					
					correct = true;
				}
				else if(temp.equals("-5")) {
					
					correct = true;
				}
				else if(temp.equals("0")) {
					
					correct = true;
				}
				else if(temp.equals("5")) {
					
					correct = true;
				}
				else if(temp.equals("10")) {
					
					correct = true;
				}
				else if(temp.equals("15")) {
					
					correct = true;
				}//invalid inputs
				else {
					
					
					System.out.println("Your last input was invalid. Acceptable inputs are (-20, -15,-10,-5, 0 , 5, 10, 15 )");
					temp = scan.nextLine();
				}
				
				
				
				
			}
			
			
			
			boolean wrong = true;// controls wind speed while loop;
			
			//Gain the wind speed
			String speed = "";
			System.out.println("\nInput the windspeed: ");
			speed = scan.nextLine();
		while( wrong ) {
				
				
				// Acceptable inputs
				 if(speed.equals("5")) {
					
					wrong = false;
				}
				else if(speed.equals("10")) {
									
					wrong = false;
				}
				else if(speed.equals("15")) {
					
					wrong = false;
				}
				else if(speed.equals("20")) {
					
					wrong = false;
				}
				else if(speed.equals("25")) {
					
					wrong = false;
				}
				else if(speed.equals("30")) {
					
					wrong = false;
				}
				//invalid inputs
				else {
					
					
					System.out.println("Your last input was invalid. Acceptable inputs are (5,10,15,20,25,30 )");
					speed = scan.nextLine();
				}
				
				
				
				
			}
			
			int windspeed  = Integer.parseInt(speed);
			
			
			// determine position of element needed
			int position = (windspeed/5) - 1;
			
			//output
			int output = 0;
			
			
			//determines which array to go to and which value to output
			 if(temp.equals("-20")) {
					
					output = neg20[position] ;
				}
				else if(temp.equals("-15")) {
									
					output = neg15[position] ;
				}
				else if(temp.equals("-10")) {
					
					output = neg10[position] ;
				}
				else if(temp.equals("-5")) {
					
					output = neg5[position] ;
				}
				else if(temp.equals("0")) {
					
					output = zero[position] ;
				}
				else if(temp.equals("5")) {
					
					output = pos5[position] ;
				}
				else if(temp.equals("10")) {
					
					output = pos10[position] ;
				}
				else if(temp.equals("15")) {
					
					output = pos15[position] ;
				}
			
			//outputs windchill factor
			 System.out.println("\nThe wind-chill factor is " + output + "\n");
			
			
			
			// Checks if the user would like to keep using this application
			
			System.out.println("Would you like to keep using this application? (input n for no)");
			
			use = scan.nextLine();
			
			if (use.equals("n")) {
				
				useagain = false;
			}
			
			
		}
		
		
		System.out.println("Have a nice day!!!");
	}
	
	
}
