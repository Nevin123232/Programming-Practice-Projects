
public class sort {
//This is the bubble sort assignment
	
	
	public static void main(String[] args) {
		
		int[] scores = {90,85,65,75,95};
		
	   for (int i = 0; i < scores.length; i++) {
			
			System.out.print(scores[i] + "  ");
			
			
		}
		
	   
	   // ascending order
	   
	   for (int i = 0; i < scores.length - 1; i++) {
			// minimum of the list of scores 
			
		   int min = scores[i];
		   int minindex = i;
		   
		   for(int j = i+ 1; j < scores.length; j++) {
			   
			   
			   if(min > scores[j]) {
				   
				   
				   
			   min = scores[j];
			   minindex = j;
			   
			   
			   
			   
			   }
		   }
		   
		   
		   //swap scores[i] with scores[j] if necassary
		   
		   if(minindex != i) {
			   
			   
			   scores[minindex] = scores[i];
			   scores[i] = min;
			   
			   
			   
		   }
			
		}
		
	  
	   
	   
	
	   /*
	     
	   // descending order
	   
	   for (int i = 0; i < scores.length - 1; i++) {
			// maximum of the list of scores 
			
		   int max = scores[i];
		   int maxindex = i;
		   
		   for(int j = i+ 1; j < scores.length; j++) {
			   
			   
			   if(max < scores[j]) {
				   
				   
				   
			   max = scores[j];
			   maxindex = j;
			   
			   
			   
			   
			   }
		   }
		   
		   
		   //swap scores[i] with scores[j] if necassary
		   
		   if(maxindex != i) {
			   
			   
			   scores[maxindex] = scores[i];
			   scores[i] = max;
			   
			   
			   
		   }
			
		}
		
	  
	   
	   
	    
	    */
		System.out.println("      ");

		System.out.println("      ");

		
		for (int i = 0; i < scores.length; i++) {
			
			System.out.print(scores[i] + "  ");
		}
		
		
	}
	
	
	
}
