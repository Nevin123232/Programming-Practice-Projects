// chapter4-pchal5-NevinN.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>


//Programming Challenge 5 page 240



// Book Club points assignment


using namespace std;

int main()
{
    int books = 0;
    cout << "Input the amount of books that you have purchased this month:\n";
    cin >> books;

    int points = 0;

    if (books <= 0) { // if the user bought 0 books 

        points = 0; 
    }
    else  if (books == 1) { // if the user bought 1 book
        points = 5;

    }
    else  if (books == 2) { // if the user bought 2 books
        points = 15;

    }
    else  if (books == 3) { // if the user bought 3 books
        points = 30;

    }
    else {
        points = 50; // if the user bought 4 or more books (all other cases)

    }

    cout << " The purchaser has been awarded " << points << " points.\n";

}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
