// Porg-chal-8-c++-NevinN.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>

using namespace std;

// Programming Challenge 8 page 320

int main()
{

	//pennies for pay

	//obtain amount of days 
	int days = 0; // initialization of days variables
	while (true) {
		cout << "Input the amount of days worked (Valid inputs: 1-31)\n";
		cin >> days;
		
		if (days >= 1 && days <= 31) {
			//days is a legitimate input
			break;

		}
		else {
			//days is not a legitimate input
			cout << "Invalid input:  ";
		}
		

	}


	int earn = 0; //initialization of the money earned variable
	long total = 0; //initialization of the total pay variable
	long counter = 1; //tracks how much pennies should be earned in a day


	for (int x = 1; x <=days; x++) {

		earn = counter; // make the earn variable counter

		counter *= 2; // doubling counter variable

        //output
		cout << "\nDay: " << x << "   Penny/Pennies earned today: " << earn ;
		total += earn; // increase total by the money earned
		cout << "    Total pennies so far: " << total;
	}


	//output the total amount of pennies
	cout << "\n\n\nThe total amount of pennies earned this month is: " << total;
	long dollars =  total * 0.01; //initialization of dollars variable (equals total pennies over 100)

	int cents = total % dollars; //obtain amount of cents 
	cout << "\n\n\nThe total amount of money earned this month is: " << dollars << "$ and " << cents << " cents";



}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
