package bikeproject;

import java.util.*;

 
public class BikeList {

	static Random rand = new Random();
	public static void main(String[] args) {
		
		ArrayList<Bike> bikes = new ArrayList<Bike>(); //ArrayList that stores bikes
		
		bikes = fillArray(bikes); //calls fillarray function to populate arraylist
		  

		
		int  mountainBikeSales = 0;
		
		int roadBikeSales = 0;
		
		System.out.println("Stock Information:");
		displayStock(bikes);
		
	
		displayBikeNumbers(bikes); //displays the amount of each bike in stock
	}
	
	
	
	public static void displayBikeNumbers(ArrayList<Bike> bikes) {

		int mb = calculateStock(bikes); //gets the amount of mountainbikes
		int rb = bikes.size() - mb; //gets amount of roadbikes
		
		System.out.println("Stock Levels:");
		System.out.println("We have " + mb +" Mountain Bikes in stock.\n");
		System.out.println("We have " + rb +" Road Bikes in stock."  );
		
		
	}
	
	 
	
	
	//calculates stock (
	public static int calculateStock(ArrayList<Bike> bikes) {
		
		int bikesSold = 0;
		
		for(int i = 0; i <bikes.size(); i++) {
			
			if(bikes.get(i) instanceof MountainBike  ) { //checks if a bike in the bikes arraylist is a new mountainbike
		
				bikesSold += 1; //increases bikessold variable by 1
		
			}
		
		}
		return bikesSold;
		
		
		
	}
	
	
	public static ArrayList<Bike> fillArray(ArrayList<Bike> bikes){
		int choose = rand.nextInt(2);
		
		
		
		
		for(int i = 0; i < 10; i++) { //for loop that adds 10 bikes to the arraylist bikes
			
		if(choose == 0) { // if choose = 0 then add a roadbike
			
			bikes.add(new RoadBike());
		//	System.out.println("A roadbike has been added\n"); // outputs that a roadbike has been added when choose = 0
		}
		else if(choose == 1) {/// if choose = 1 then add a mountainbike
			
			
			bikes.add(new MountainBike());
			// System.out.println("A mountainbike has been added\n");  // outputs that a mountainbike has been added when choose = 0
		}
		
		choose = rand.nextInt(2); //rerandomizes choose variabele
		
		}
		
		
		return bikes; //returns the newly made arraylist
	}
	
	
	public static void displayStock(ArrayList<Bike> bikes) {
		
		for(int i = 0; i <bikes.size(); i++) {
			
			
			System.out.println(bikes.get(i) + "\n");
		}
		
		
		
	}
	
	
	
}
