
import java.util.*; // This imports everything but java.util.Scanner brings in the scanner




public class life {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner scan = new Scanner(System.in);
		
        String test[] = {"", "", "", "", "", ""};
		
		for (int i = 0; i < test.length ; i++) {
			
			System.out.println("\n Input something into the array \n");
			test[i] = scan.nextLine(); 
			
		}
	    
		
		System.out.println("You have inputted  "  + test.length + " Things into the array \n");
		
        for (int i = test.length - 1; i > -1; i--) {
			
			System.out.println(test[i] + "\n");
			
		}
        
		scan.close();
	}

}
