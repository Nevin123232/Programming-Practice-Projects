// p-chal-12-chapter6.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>


using namespace std;
//Programming challenge 12 on page 407 by Nevin Ndonwi

//Present Value problem


double presentValue(double fv, double i, double m) {

    double b = 1 + i;
    double presentval = pow(b,m);

    double g = fv / presentval;

    return g;
}




int main()
{
    double fv = 0;
    double interest = 0;
    int years = 0;

    cout << "Welcome to the Present Value Application!\n";

    cout << "Input the future value: \n";
    cin >> fv;

    cout << "Input the annual interest: \n";
    cin >> interest;

    cout << "Input the years: \n";
    cin >> years;



    double output = presentValue(fv, (interest / 12), (years * 12));
    cout << "\nThe Present Value is " << output;

    
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
