
"line equation finder"


from tkinter import *

root = Tk()

# setting the minimum / maximum size of the root window 

#root.minsize(200, 200) 
#root.maxsize(200,200)
#correct maze tiles

l1  = Label(root, padx = 50, pady = 10, bg = "blue")
l2  = Label(root, padx = 10, pady = 40, bg = "blue")








l3  = Label(root, padx = 10, pady = 10, bg = "blue")
l4  = Label(root, padx = 10, pady = 10, bg = "blue")
l5  = Label(root, padx = 10, pady = 10, bg = "blue")
l6  = Label(root, padx = 10, pady = 10, bg = "blue")
l7  = Label(root, padx = 10, pady = 10, bg = "blue")
l8  = Label(root, padx = 10, pady = 10, bg = "blue")
l9  = Label(root, padx = 10, pady = 10, bg = "blue")
l10 = Label(root, padx = 10, pady = 10, bg = "blue")
l11 = Label(root, padx = 10, pady = 10, bg = "blue")
l12 = Label(root, padx = 10, pady = 10, bg = "blue")
l13 = Label(root, padx = 10, pady = 10, bg = "blue")
l14 = Label(root, padx = 10, pady = 10, bg = "blue")
l15 = Label(root, padx = 10, pady = 10, bg = "blue")
l16 = Label(root, padx = 10, pady = 10, bg = "blue")
l17 = Label(root, padx = 10, pady = 10, bg = "blue")
l18 = Label(root, padx = 10, pady = 10, bg = "blue")
l19 = Label(root, padx = 10, pady = 10, bg = "blue")
l20 = Label(root, padx = 10, pady = 10, bg = "blue")
l21 = Label(root, padx = 10, pady = 10, bg = "blue")
l22 = Label(root, padx = 10, pady = 10, bg = "blue")
l23 = Label(root, padx = 10, pady = 10, bg = "blue")








#bg = background 
bg1 = Label(root, padx = 10, pady = 90)
bg2 = Label(root, padx = 10, pady = 100)


bg3 = Label(root, padx = 10, pady = 90)
bg4 = Label(root, padx = 10, pady = 100)

#placing the labels
l1.grid(row = 90,column = 0)
l2.grid(row = 90,column = 40)
bg1.grid(row = 0, column = 0)
bg2.grid(row = 100, column = 0)
b3.grid(row = 0, column = 40)
b4.grid(row = 15, column = 40)
root.mainloop()