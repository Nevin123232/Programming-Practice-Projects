/* Author: Will Molloy and Nevin Ndonwi

 * Date: 7/26/2020
 */

package ui;
import business.*;
import java.lang.reflect.Method;
import java.util.*;
import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;


public class EmpUI extends javax.swing.JFrame {

String filename;
Map<Long,Employee> emps;
Map<String,Employee> empbyname;
Map<String,JTextField> screenMap;
JTextField[] fields;
String[] getMethods={"getEmpno","getFirstName","getLastName","getSuffix","getMiddleName",
"getAddress1","getAddress2","getCity","getState","getZip","getPhone","getGender",
"getPaycode","getStatus"};
int loading=0;



    public EmpUI() {
        initComponents();
        //initialize UI form/disable buttons
       
        JTextField[] flds = {jTextFieldEmpNo,jTextFieldFirstnm,jTextFieldLastnm,
            jTextFieldMiddlenm,jTextFieldSuffix,jTextFieldAddr1,jTextFieldAddr2,
            jTextFieldCity,jTextFieldState,jTextFieldZip,jTextFieldPhone,jTextFieldGender,
            jTextFieldStatus,jTextFieldStatus,jTextFieldHiredt,jTextFieldTermdt};
        fields=flds;
        screenMap=new HashMap<>();
        //associate getMethod String with specified text fields
           for(int i = 0;i<getMethods.length;i++) {
               screenMap.put(getMethods[i],fields[i]);
        }
           disableFields(false);
           jButtonAdd.setEnabled(false);
           jButtonUpdate.setEnabled(false);
           jButtonDelete.setEnabled(false);
           jButtonSave.setEnabled(false);
           jButtonClear.setEnabled(false);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jRadioButtonRawHash = new javax.swing.JRadioButton();
        jRadioButtonTreeMap = new javax.swing.JRadioButton();
        jRadioButtonNameKey = new javax.swing.JRadioButton();
        jButtonPrevious = new javax.swing.JButton();
        jComboBoxEmployees = new javax.swing.JComboBox();
        jLabel1 = new javax.swing.JLabel();
        jButtonNext = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jTextFieldEmpNo = new javax.swing.JTextField();
        jTextFieldLastnm = new javax.swing.JTextField();
        jTextFieldMiddlenm = new javax.swing.JTextField();
        jTextFieldFirstnm = new javax.swing.JTextField();
        jTextFieldSuffix = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jTextFieldAddr1 = new javax.swing.JTextField();
        jTextFieldAddr2 = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jTextFieldCity = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jTextFieldState = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        jTextFieldZip = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        jTextFieldPhone = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        jTextFieldGender = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        jTextFieldPaycd = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        jTextFieldStatus = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        jTextFieldHiredt = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        jTextFieldTermdt = new javax.swing.JTextField();
        jLabelMsg = new javax.swing.JLabel();
        jButtonAdd = new javax.swing.JButton();
        jButtonUpdate = new javax.swing.JButton();
        jButtonDelete = new javax.swing.JButton();
        jButtonSave = new javax.swing.JButton();
        jButtonClear = new javax.swing.JButton();
        jButtonExit = new javax.swing.JButton();
        menuBar = new javax.swing.JMenuBar();
        fileMenu = new javax.swing.JMenu();
        openMenuItem = new javax.swing.JMenuItem();
        exitMenuItem = new javax.swing.JMenuItem();
        helpMenu = new javax.swing.JMenu();
        contentsMenuItem = new javax.swing.JMenuItem();
        aboutMenuItem = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        buttonGroup1.add(jRadioButtonRawHash);
        jRadioButtonRawHash.setText("Raw HashMap w.Empno Key");
        jRadioButtonRawHash.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButtonRawHashActionPerformed(evt);
            }
        });

        buttonGroup1.add(jRadioButtonTreeMap);
        jRadioButtonTreeMap.setText("TreeMap by Empno");
        jRadioButtonTreeMap.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButtonTreeMapActionPerformed(evt);
            }
        });

        buttonGroup1.add(jRadioButtonNameKey);
        jRadioButtonNameKey.setText("Map with Name Key (sorted)");
        jRadioButtonNameKey.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButtonNameKeyActionPerformed(evt);
            }
        });

        jButtonPrevious.setText("<-");
        jButtonPrevious.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonPreviousActionPerformed(evt);
            }
        });

        jComboBoxEmployees.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jComboBoxEmployees.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jComboBoxEmployeesItemStateChanged(evt);
            }
        });

        jLabel1.setText("Employees:");

        jButtonNext.setText("->");
        jButtonNext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonNextActionPerformed(evt);
            }
        });

        jPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel2.setText("EmpNo:");

        jLabel3.setText("Name: Last");

        jLabel4.setText("First");

        jLabel5.setText("Mid");

        jLabel6.setText("Suffix");

        jLabel7.setText("Addr:");

        jLabel8.setText("City:");

        jLabel9.setText("State:");

        jLabel10.setText("Zip:");

        jLabel11.setText("Phone:");

        jLabel12.setText("Gender:");

        jLabel13.setText("Pay Cd:");

        jLabel14.setText("Status:");

        jLabel15.setText("Hire Date:");

        jLabel16.setText("Terminate Date:");

        jLabelMsg.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabelMsg.setText("jLabel17");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(jTextFieldEmpNo, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3)
                            .addComponent(jTextFieldLastnm, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4)
                            .addComponent(jTextFieldFirstnm, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTextFieldMiddlenm, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel6)
                            .addComponent(jTextFieldSuffix, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel7)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jTextFieldAddr2, javax.swing.GroupLayout.DEFAULT_SIZE, 441, Short.MAX_VALUE)
                                    .addComponent(jTextFieldAddr1)))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addComponent(jLabel8)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jTextFieldCity, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addComponent(jLabel11)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jTextFieldPhone, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addGap(14, 14, 14)
                                        .addComponent(jLabel14)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jTextFieldStatus, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jLabel15)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jTextFieldHiredt, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addComponent(jLabel12)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jTextFieldGender, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addComponent(jLabel9)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jTextFieldState, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addGap(11, 11, 11)
                                        .addComponent(jLabel13)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jTextFieldPaycd, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addGap(2, 2, 2)
                                        .addComponent(jLabel10)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jTextFieldZip, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addGap(18, 18, 18)
                                        .addComponent(jLabel16)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jTextFieldTermdt, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addComponent(jLabelMsg, javax.swing.GroupLayout.PREFERRED_SIZE, 480, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 15, Short.MAX_VALUE)))
                .addGap(28, 28, 28))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jLabel3)
                    .addComponent(jLabel4)
                    .addComponent(jLabel5)
                    .addComponent(jLabel6))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextFieldEmpNo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextFieldLastnm, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextFieldMiddlenm, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextFieldFirstnm, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextFieldSuffix, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(jTextFieldAddr1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTextFieldAddr2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(jTextFieldCity, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9)
                    .addComponent(jTextFieldState, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10)
                    .addComponent(jTextFieldZip, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(jTextFieldPhone, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel12)
                    .addComponent(jTextFieldGender, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel13)
                    .addComponent(jTextFieldPaycd, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel14)
                    .addComponent(jTextFieldStatus, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel15)
                    .addComponent(jTextFieldHiredt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel16)
                    .addComponent(jTextFieldTermdt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jLabelMsg, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jButtonAdd.setText("Add");

        jButtonUpdate.setText("Update");

        jButtonDelete.setText("Delete");

        jButtonSave.setText("Save ");

        jButtonClear.setText("Clear");
        jButtonClear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonClearActionPerformed(evt);
            }
        });

        jButtonExit.setText("Exit");
        jButtonExit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonExitActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jRadioButtonRawHash)
                            .addComponent(jButtonPrevious))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jComboBoxEmployees, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jButtonNext))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(jRadioButtonTreeMap)
                                .addGap(18, 18, 18)
                                .addComponent(jRadioButtonNameKey))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jButtonAdd, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButtonUpdate, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButtonDelete, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButtonSave, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButtonClear, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButtonExit, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jRadioButtonRawHash)
                    .addComponent(jRadioButtonTreeMap)
                    .addComponent(jRadioButtonNameKey))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButtonPrevious)
                    .addComponent(jComboBoxEmployees, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1)
                    .addComponent(jButtonNext))
                .addGap(18, 18, 18)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButtonExit)
                    .addComponent(jButtonClear)
                    .addComponent(jButtonSave)
                    .addComponent(jButtonDelete)
                    .addComponent(jButtonUpdate)
                    .addComponent(jButtonAdd))
                .addContainerGap(24, Short.MAX_VALUE))
        );

        fileMenu.setMnemonic('f');
        fileMenu.setText("File");

        openMenuItem.setMnemonic('o');
        openMenuItem.setText("Load CSV file");
        openMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                openMenuItemActionPerformed(evt);
            }
        });
        fileMenu.add(openMenuItem);

        exitMenuItem.setMnemonic('x');
        exitMenuItem.setText("Exit");
        exitMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitMenuItemActionPerformed(evt);
            }
        });
        fileMenu.add(exitMenuItem);

        menuBar.add(fileMenu);

        helpMenu.setMnemonic('h');
        helpMenu.setText("Help");

        contentsMenuItem.setMnemonic('c');
        contentsMenuItem.setText("Contents");
        helpMenu.add(contentsMenuItem);

        aboutMenuItem.setMnemonic('a');
        aboutMenuItem.setText("About");
        helpMenu.add(aboutMenuItem);

        menuBar.add(helpMenu);

        setJMenuBar(menuBar);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 6, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void exitMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitMenuItemActionPerformed
        System.exit(0);
    }//GEN-LAST:event_exitMenuItemActionPerformed

    private void openMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_openMenuItemActionPerformed
        //declare file chooser and set it to current dir
        JFileChooser f=new JFileChooser(".");
        f.setDialogTitle("Select Employee File");//display dialog title
        //create file filter for CSV files
        FileNameExtensionFilter filter = new FileNameExtensionFilter("CSV file "
                + "(*.csv)","CSV");
        f.setFileFilter(filter);
        JDialog jd=new JDialog();
        int rval=f.showOpenDialog(jd);//use JDialog as parent frame
        if (rval==JFileChooser.CANCEL_OPTION) {
            jLabelMsg.setText("Open file operation canceled");
            } else {
            filename=f.getSelectedFile().getAbsolutePath();//get filename and path
            emps=EmployeeIO.getEmployees(filename);//call getEmployees() method
            jLabelMsg.setText(String.valueOf(emps.size())+" records found");
            disableFields(true);
        }
    }//GEN-LAST:event_openMenuItemActionPerformed

    private void jRadioButtonRawHashActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButtonRawHashActionPerformed
        try {
            if(jRadioButtonRawHash.isSelected()) {
                buildComboBox();
                jLabelMsg.setText("Raw HashMap populated. Select employee "
                +"Number to display employee information");
                loading=0;
                jButtonClear.setEnabled(true);
            }
        }
        catch (NullPointerException e) {
            jLabelMsg.setText("Error occured. No record loaded." + "Please select a csv file to load");
            fileMenu.doClick();
            buttonGroup1.clearSelection();
        }
        
    }//GEN-LAST:event_jRadioButtonRawHashActionPerformed

    private void jRadioButtonTreeMapActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButtonTreeMapActionPerformed
        try {
            if(jRadioButtonTreeMap.isSelected()) {
                buildComboBox();
                jLabelMsg.setText("Raw TreeMap populated. Select employee "
                +"Number to display employee information");
                loading=0;
                jButtonClear.setEnabled(true);
            }
        }
        catch (NullPointerException e) {
            jLabelMsg.setText("Error occured. No record loaded." + "Please select a csv file to load");
            fileMenu.doClick();
            buttonGroup1.clearSelection();
        }
    }//GEN-LAST:event_jRadioButtonTreeMapActionPerformed

    private void jRadioButtonNameKeyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButtonNameKeyActionPerformed
        try {
            if(jRadioButtonNameKey.isSelected()) {
                buildComboBox();
                jLabelMsg.setText("Name key populated. Select employee "
                +"Number to display employee information");
                loading=0;
                jButtonClear.setEnabled(true);
            }
        }
        catch (NullPointerException e) {
            jLabelMsg.setText("Error occured. No record loaded." + "Please select a csv file to load");
            fileMenu.doClick();
            buttonGroup1.clearSelection();
        }
    }//GEN-LAST:event_jRadioButtonNameKeyActionPerformed

    private void jComboBoxEmployeesItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_jComboBoxEmployeesItemStateChanged
        if (loading==1) {
            return;
        }
        else {
            Employee e;
            if(jRadioButtonNameKey.isSelected()){
                e=(Employee)empbyname.get((String)jComboBoxEmployees.getSelectedItem());
            }
            else {
                e=(Employee)emps.get((Long)jComboBoxEmployees.getSelectedItem());
            }
            String recordinfo="You are viewing record for: ";
            if(e.getMiddleName()==null){
            recordinfo+=e.getLastName()+", "+e.getFirstName();
            } else{
            recordinfo+=e.getLastName()+", "+e.getFirstName()+" "+e.getMiddleName();
            }
            displayValues(e);
            jLabelMsg.setText(recordinfo);
        }
    }//GEN-LAST:event_jComboBoxEmployeesItemStateChanged

    private void jButtonPreviousActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonPreviousActionPerformed
       if(!(jComboBoxEmployees.getSelectedIndex() <= 0)) {
           jComboBoxEmployees.setSelectedIndex(jComboBoxEmployees.getSelectedIndex() - 1);
       }
       else {
           jLabelMsg.setText("You have reached the first employee record on file.");
       }
    }//GEN-LAST:event_jButtonPreviousActionPerformed

    private void jButtonNextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonNextActionPerformed
        if(!(jComboBoxEmployees.getSelectedIndex()>= emps.size()-1)) {
            jComboBoxEmployees.setSelectedIndex(jComboBoxEmployees.getSelectedIndex()+1);
        } else {
            jLabelMsg.setText("You have reached the last employee record on file.");
        }
    }//GEN-LAST:event_jButtonNextActionPerformed

    private void jButtonClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonClearActionPerformed
        clearTextfields();
    }//GEN-LAST:event_jButtonClearActionPerformed

    private void jButtonExitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonExitActionPerformed
        System.exit(0);
    }//GEN-LAST:event_jButtonExitActionPerformed
    private void buildComboBox() {
        loading=1;
        jComboBoxEmployees.removeAllItems();
       clearTextfields();
        if(jRadioButtonRawHash.isSelected()) {
            //HashMap is a class that implements a map
            //the (key,value) pairs of the map are stored using a hash table
            HashMap<Long,Employee> hashMap = new HashMap<>(emps);
            for(Map.Entry<Long,Employee> entry:hashMap.entrySet()){
               Long k=entry.getKey();
               //if(jComboBoxEmployees.getSelectedItem()==null) {
               //continue;
               //}
               jComboBoxEmployees.addItem(k);
            }
        }
        else if(jRadioButtonTreeMap.isSelected()) {
            //Tree map is a data structure tha implements Map<key,value> interface
            //and it is based on Red-Black tree data structure
            TreeMap<Long,Employee> treeMap=new TreeMap<>(emps);
            for(Map.Entry<Long,Employee> entry: treeMap.entrySet()) {
                Long k=entry.getKey();
                jComboBoxEmployees.addItem(k);
            }
        }
        else if(jRadioButtonNameKey.isSelected()) {
            empbyname=new TreeMap<>();
            for (Map.Entry<Long,Employee> entry: emps.entrySet()) {
                Employee e = entry.getValue();
                if(e.getMiddleName()==null){
                    String name = e.getLastName()+", "+e.getFirstName();
                    empbyname.put(name,e);
                } else if(e.getMiddleName()!=null){
                    String name = e.getLastName()+", "+e.getFirstName()+" " +e.getMiddleName();
                    empbyname.put(name,e);
                }
                
        }
            for (Map.Entry<String,Employee> entry: empbyname.entrySet()) {
                String k = entry.getKey();
                jComboBoxEmployees.addItem(k);
            }
        }
        clearTextfields();
        jComboBoxEmployees.setSelectedIndex(-1);
        loading=0;
    }
    public void clearTextfields() {
        for(JTextField f: fields) {
            f.setText("");
        }
    }
    private void displayValues(Employee e) {
        clearTextfields();
        //use reflection method in java.lang.reflect package
        Class empClass = e.getClass();
        Method[] methods = empClass.getMethods();
        try {
            for (Method m : methods) {
                if(screenMap.containsKey(m.getName())) {
                   
                    JTextField field = screenMap.get(m.getName());
                    switch(m.getName()){
                      case "getEmpno":
                        long x = (long) m.invoke(e,null);
                        field = screenMap.get(m.getName());
                        field.setText(String.valueOf(x));
                        break;
                      case "getPhone":
                          int y=(int)m.invoke(e,null);
                          field=screenMap.get(m.getName());
                          field.setText(String.valueOf(y));
                          break;
                      case "getPayCode":
                          int z=(int)m.invoke(e,null);
                          field = screenMap.get(m.getName());
                          field.setText(String.valueOf(z));
                          break;      
                      default:
                          if(String.valueOf(m.invoke(e,null)).equals("null")) {
                              field.setText("");
                          }
                          else {
                              field.setText(String.valueOf(m.invoke(e,null)));
                          }
                              break;
                        
                    }
                    
                }
            }
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    public void disableFields(boolean option) {
        JTextField[] flds = {jTextFieldEmpNo,jTextFieldFirstnm,jTextFieldLastnm,
            jTextFieldMiddlenm,jTextFieldSuffix,jTextFieldAddr1,jTextFieldAddr2,
            jTextFieldCity,jTextFieldState,jTextFieldZip,jTextFieldPhone,jTextFieldGender,
            jTextFieldStatus,jTextFieldStatus,jTextFieldHiredt,jTextFieldTermdt};
        fields=flds;
    for (JTextField fld : flds) {
        fld.setEnabled(option);
        
    }
    jComboBoxEmployees.setEnabled(option);
    jTextFieldPaycd.setEnabled(option);
    jButtonPrevious.setEnabled(option);
    jButtonNext.setEnabled(option);
    jComboBoxEmployees.setEnabled(option);
    }

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(EmpUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(EmpUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(EmpUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(EmpUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new EmpUI().setVisible(true);
            }
        });
        
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem aboutMenuItem;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JMenuItem contentsMenuItem;
    private javax.swing.JMenuItem exitMenuItem;
    private javax.swing.JMenu fileMenu;
    private javax.swing.JMenu helpMenu;
    private javax.swing.JButton jButtonAdd;
    private javax.swing.JButton jButtonClear;
    private javax.swing.JButton jButtonDelete;
    private javax.swing.JButton jButtonExit;
    private javax.swing.JButton jButtonNext;
    private javax.swing.JButton jButtonPrevious;
    private javax.swing.JButton jButtonSave;
    private javax.swing.JButton jButtonUpdate;
    private javax.swing.JComboBox jComboBoxEmployees;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLabel jLabelMsg;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JRadioButton jRadioButtonNameKey;
    private javax.swing.JRadioButton jRadioButtonRawHash;
    private javax.swing.JRadioButton jRadioButtonTreeMap;
    private javax.swing.JTextField jTextFieldAddr1;
    private javax.swing.JTextField jTextFieldAddr2;
    private javax.swing.JTextField jTextFieldCity;
    private javax.swing.JTextField jTextFieldEmpNo;
    private javax.swing.JTextField jTextFieldFirstnm;
    private javax.swing.JTextField jTextFieldGender;
    private javax.swing.JTextField jTextFieldHiredt;
    private javax.swing.JTextField jTextFieldLastnm;
    private javax.swing.JTextField jTextFieldMiddlenm;
    private javax.swing.JTextField jTextFieldPaycd;
    private javax.swing.JTextField jTextFieldPhone;
    private javax.swing.JTextField jTextFieldState;
    private javax.swing.JTextField jTextFieldStatus;
    private javax.swing.JTextField jTextFieldSuffix;
    private javax.swing.JTextField jTextFieldTermdt;
    private javax.swing.JTextField jTextFieldZip;
    private javax.swing.JMenuBar menuBar;
    private javax.swing.JMenuItem openMenuItem;
    // End of variables declaration//GEN-END:variables

}
