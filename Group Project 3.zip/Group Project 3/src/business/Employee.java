
package business;
/**Employee class
 * Date: 6/5/21
 * @author jmercer
 */
public class Employee {
    private long empno;
    private int phone;
    private int paycode;
    private String firstName;
    private String lastName;
    private String middleName;
    private String suffix;
    private String address1;
    private String address2;
    private String city;
    private String state;
    private String zip;
    private String gender;
    private String status;
    private String hiredt;
    private String termdt;
    //constructor
    public Employee() {
        //initialize int
        empno=0;
        phone=0;
        paycode=0;
        String[] fields={lastName,firstName,middleName,suffix,address1,
            address2,city,state,zip,gender,status,hiredt,termdt};
        //initialize String fields
        for (String s: fields) { 
            s="";
        }
    }
    public Employee(long empno, int phone, int paycode, String lastName, String firstName,
            String middleName, String suffix, String address1, String address2,
            String city, String state, String zip, String gender, String status,
            String hireDate, String termDate) {
        this.empno = empno;
        this.phone = phone;
        this.paycode = paycode;
        this.lastName = lastName;
        this.firstName = firstName;
        this.middleName = middleName;
        this.suffix = suffix;
        this.address1 = address1;
        this.address2 = address2;
        this.city = city;
        this.state = state;
        this.zip = zip;
        this.gender = gender;
        this.status = status;
        this.hiredt = hireDate;
        this.termdt = termDate;
    }

    public long getEmpno() {
        return empno;
    }

    public void setEmpno(long empno) {
        this.empno = empno;
    }

    public int getPhone() {
        return phone;
    }

    public void setPhone(int phone) {
        this.phone = phone;
    }

    public int getPaycode() {
        return paycode;
    }

    public void setPaycode(int paycode) {
        this.paycode = paycode;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }
    public String getFullName() {
        return this.lastName+", "+this.firstName+" "+this.middleName;
    }
    public String getSuffix() {
        return suffix;
    }

    public void setSuffix(String suffix) {
        this.suffix = suffix;
    }

    public String getAddress1() {
        return address1;
    }

    public void setAddress1(String address1) {
        this.address1 = address1;
    }

    public String getAddress2() {
        return address2;
    }

    public void setAddress2(String address2) {
        this.address2 = address2;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getZip() {
        return zip;
    }

    public void setZip(String zip) {
        this.zip = zip;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getHiredt() {
        return hiredt;
    }

    public void setHiredt(String hiredt) {
        this.hiredt = hiredt;
    }

    public String getTermdt() {
        return termdt;
    }

    public void setTermdt(String termdt) {
        this.termdt = termdt;
    }
    //override toString() method
    @Override
    public String toString() {
        return this.empno+","+this.firstName+","+this.lastName+","+this.middleName
                +","+this.suffix+","+this.address1+","+this.address2+","+this.city
                +","+this.state+","+this.zip+","+this.phone+","+this.gender+","
                +this.status+","+this.hiredt+","+this.termdt+","+this.paycode;
    }
}

