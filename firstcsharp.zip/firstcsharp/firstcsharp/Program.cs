﻿using System;

namespace firstcsharp
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("\n Hello World!\n"); // outputs text 
            Console.WriteLine("\nInput a string \n");
            string input = Console.ReadLine(); // reads input 

            Console.WriteLine("\nThe user has inputted  " + input);

            Console.WriteLine("\n Input a number\n");
            string rick = Console.ReadLine();
            
            int oof = int.Parse(rick); // converts string input to integer

            int ynaut = oof + 2; 

            Console.WriteLine("\n You inputted  " + rick + " and  " + rick + " +  2 " + " = " + ynaut + "\n");
            
        }
    }
}
