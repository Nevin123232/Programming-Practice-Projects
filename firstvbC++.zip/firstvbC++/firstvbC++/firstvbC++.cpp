// firstvbC++.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
using namespace std;
int main()
{ 
	string CharacterName;
	string CharacterName2;
	string bodypart1;
	string game2;
	string school3;
	string disease4;
	string oof5;
	
	cout << "input a sticky food ";
		cin >> oof5; 
		cout << "put in a sickness ";
			cin >> disease4;
			cout << "put in a school ";
			cin >> school3;
			cout << "input your favorite video game "; 
			cin >> game2;
			cout << "input a body part ";
			cin >> bodypart1;

			cout << "input your name ";
			cin >> CharacterName;
			cout << "input the name of your enemy "; 
			cin >> CharacterName2;
			
			cout << " One day,  " << CharacterName2 << "  called " << CharacterName << "   ugly and stupid in class. \n";
			cout << " Then when you went home to play  " << game2 << "   but  " << CharacterName << "  's mother said that   " << CharacterName << " did terribly on a test \n";
			cout << " After that " << CharacterName2 << "  went for a walk to think about how beautiful they were \n";
			cout << " but then a lot of  " << oof5 << "   fell on their hair \n";
			cout << " But when   " << CharacterName2 << "  came back to their house   " << CharacterName2 << "   felt sick and realized that they caught  " << disease4 << "   sadly \n";
				cout << "  In order to cure  " << CharacterName2 << "   they had to cut off the  " << bodypart1 << "    of  " << CharacterName2 << "  sadly \n";
			cout << "   And then she died\n";










	

	return 0; 
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
