#crreates interface
from tkinter import *

root = Tk()
root.title = "This is my project idiots"


def myclick():
    if e.get().strip() == "text":
      s = Label(root, text = " You have input the right word", padx = 10, pady = 10)
      s.pack()
    else:
     mylabel = Label(root, text = "You have typed " + e.get(), padx = 50, pady = 50)
     mylabel.pack() 








e = Entry(root, width = 50)
e.pack()
mybutton = Button(root, text = "press me ", command = myclick)
mybutton.pack()

extbtn = Button(root, text = "I want to get out of here",command = root.quit)
extbtn.pack()



  

root.mainloop()

#basic user interface like in visual basic

