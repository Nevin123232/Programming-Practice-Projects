package genericshapes;
import java.util.*;
public class driver {

	
	
	
	 
	
	//modified method within driver class 
	public static void main(String[] args) {
		
		
		
	
		Cuboid<Double> c1 = new Cuboid<>();
		c1.setLength(1.3);
		c1.setBreadth(2.2);
		c1.setHeight(2.0);
		System.out.println(c1);
		Cuboid<Integer> c2 = new Cuboid<>(1,2,3);
		System.out.println(c2);
		System.out.println(c1.getVolume());
		System.out.println(c2.getVolume());
		}//end method main
	
	
	
	/*
	Previous method withing driver class
	public static void main(String[] args) {
		Cuboid<Double> c1 = new Cuboid<>();
		c1.setLength(1.3);
		c1.setBreadth(2.2);
		c1.setHeight(2.0);
		Cuboid<Integer> c2 = new Cuboid<>(1,2,3);
		System.out.println(c1);
		System.out.println(c2);
		}//end method main
	
	*/
	
	
	
	
	
	
	
}// end class driver



//Modified Cuboid class

 class Cuboid<T extends Number> {
private T length;
private T breadth;
private T height;
public Cuboid() {
}//end constructor
public Cuboid(T length, T breadth, T height) {
this.length = length;
this.breadth = breadth;
this.height = height;
}//end constructor

public void setLength(T length) {
this.length = length;
}//end method setLength
public void setHeight(T height) {
this.height = height;
}//end method setHeight
public void setBreadth(T breadth) {
this.breadth = breadth;
}//end method setBreadth
public T getLength() {
return length;
}//end method getLength
public T getHeight() {
return height;
}//end method getHeight
public T getBreadth() {
return breadth;
}//end method getBreadth
public String toString() {
return ("Length: " + length + "\n" + "Height:" + height + "\n"
+ "Breadth: " + breadth + "\n");
}//end method toString
public double getVolume() {
return length.doubleValue() * height.doubleValue() *
 breadth.doubleValue();
}//end method getVolume
}//end class Cuboid




//Previous Cuboid class

/*

 class Cuboid<T> {
private T length;
private T breadth;
private T height; 
public Cuboid() {
}//end constructor
public Cuboid(T length, T breadth, T height) {
this.length = length;
this.breadth = breadth;
this.height = height;
}//end constructor
public void setLength(T length) {
this.length = length;
}//end method setLength
public void setHeight(T height) {
this.height = height;
}//end method setHeight
public void setBreadth(T breadth) {
this.breadth = breadth;
}//end method setBreadth

public T getLength() {
return length;
}//end method getLength
public T getHeight() {
return height;
}//end method getHeight
public T getBreadth() {
return breadth;
}//end method getBreadth
public String toString() {
return ("Length: " + length + "\n" + "Height: " + height + "\n"
+ "Breadth: "+ breadth + "\n");
}//end method toString


}//end class Cuboid


*/