﻿Option Strict On
Option Infer Off
Option Explicit On

Public Class frmmain


    Private Sub btnrandom_Click(sender As Object, e As EventArgs) Handles btnrandom.Click
        lblanswer.Visible = False

        Dim rand As Double
        rand = Int((13) * Rnd() + 0)
        lblout.Text = rand.ToString()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()

    End Sub

    Private Sub frmmain_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        pborat.Image = My.Resources.apikawithglasses
    End Sub

    Private Sub lbnums_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lbnums.SelectedIndexChanged
        lblanswer.Visible = False
        lbloutput.Text = CStr(lbnums.SelectedItem)
    End Sub

    Private Sub btnshow_Click(sender As Object, e As EventArgs) Handles btnshow.Click



        Dim num1 As Double

        Double.TryParse(lbloutput.Text, num1)

        Dim num2 As Double

        Double.TryParse(lblout.Text, num2)  'is a method that returns true or false idiot

        Dim result As Double = num1 * num2

        lblanswer.Text = result.ToString()

        lblanswer.Visible = True

    End Sub
End Class
