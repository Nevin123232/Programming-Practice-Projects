﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmmain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lbloutput = New System.Windows.Forms.Label()
        Me.btnrandom = New System.Windows.Forms.Button()
        Me.lblout = New System.Windows.Forms.Label()
        Me.lblanswer = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.pborat = New System.Windows.Forms.PictureBox()
        Me.lbnums = New System.Windows.Forms.ListBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.btnshow = New System.Windows.Forms.Button()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        CType(Me.pborat, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lbloutput
        '
        Me.lbloutput.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbloutput.Location = New System.Drawing.Point(50, 160)
        Me.lbloutput.Name = "lbloutput"
        Me.lbloutput.Size = New System.Drawing.Size(114, 41)
        Me.lbloutput.TabIndex = 0
        '
        'btnrandom
        '
        Me.btnrandom.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnrandom.Location = New System.Drawing.Point(281, 265)
        Me.btnrandom.Name = "btnrandom"
        Me.btnrandom.Size = New System.Drawing.Size(199, 69)
        Me.btnrandom.TabIndex = 1
        Me.btnrandom.Text = " Randomize Number 2"
        Me.btnrandom.UseVisualStyleBackColor = True
        '
        'lblout
        '
        Me.lblout.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblout.Location = New System.Drawing.Point(322, 157)
        Me.lblout.Name = "lblout"
        Me.lblout.Size = New System.Drawing.Size(38, 41)
        Me.lblout.TabIndex = 2
        '
        'lblanswer
        '
        Me.lblanswer.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblanswer.Location = New System.Drawing.Point(577, 155)
        Me.lblanswer.Name = "lblanswer"
        Me.lblanswer.Size = New System.Drawing.Size(147, 41)
        Me.lblanswer.TabIndex = 3
        Me.lblanswer.Visible = False
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(206, 157)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(36, 38)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "X"
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(514, 160)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(47, 41)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "="
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(691, 398)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(97, 40)
        Me.btnExit.TabIndex = 6
        Me.btnExit.Text = "E&xit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'pborat
        '
        Me.pborat.Location = New System.Drawing.Point(245, 9)
        Me.pborat.Name = "pborat"
        Me.pborat.Size = New System.Drawing.Size(258, 119)
        Me.pborat.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pborat.TabIndex = 7
        Me.pborat.TabStop = False
        '
        'lbnums
        '
        Me.lbnums.FormattingEnabled = True
        Me.lbnums.Items.AddRange(New Object() {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13"})
        Me.lbnums.Location = New System.Drawing.Point(16, 243)
        Me.lbnums.Name = "lbnums"
        Me.lbnums.Size = New System.Drawing.Size(188, 186)
        Me.lbnums.TabIndex = 8
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(12, 216)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(192, 24)
        Me.Label3.TabIndex = 9
        Me.Label3.Text = "Choose a Number!!"
        '
        'btnshow
        '
        Me.btnshow.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnshow.Location = New System.Drawing.Point(560, 279)
        Me.btnshow.Name = "btnshow"
        Me.btnshow.Size = New System.Drawing.Size(155, 55)
        Me.btnshow.TabIndex = 10
        Me.btnshow.Text = "Show answer"
        Me.btnshow.UseVisualStyleBackColor = True
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(596, 131)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(80, 24)
        Me.Label4.TabIndex = 11
        Me.Label4.Text = "Answer"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(311, 131)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(102, 24)
        Me.Label5.TabIndex = 12
        Me.Label5.Text = "Number 2"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(41, 131)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(102, 24)
        Me.Label6.TabIndex = 13
        Me.Label6.Text = "Number 1"
        '
        'frmmain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.btnshow)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.lbnums)
        Me.Controls.Add(Me.pborat)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.lblanswer)
        Me.Controls.Add(Me.lblout)
        Me.Controls.Add(Me.btnrandom)
        Me.Controls.Add(Me.lbloutput)
        Me.Name = "frmmain"
        Me.Text = "Math For Dummies"
        CType(Me.pborat, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lbloutput As Label
    Friend WithEvents btnrandom As Button
    Friend WithEvents lblout As Label
    Friend WithEvents lblanswer As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents btnExit As Button
    Friend WithEvents pborat As PictureBox
    Friend WithEvents lbnums As ListBox
    Friend WithEvents Label3 As Label
    Friend WithEvents btnshow As Button
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
End Class
