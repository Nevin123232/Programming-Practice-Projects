package looptest;

import java.util.Scanner;
public class LoopPattern {
public static void main (String [] args) {

Scanner in = new Scanner(System.in);

int i;
int j;

System.out.print("Enter an integer to be a limit of the pattern:");
int num = in.nextInt();

System.out.println("Pattern A:");
for (i = 1; i <= num; i++) {

for (j = 1; j <= i; j++) System.out.print(j + " ");
System.out.println();

}
System.out.println();
System.out.println("Pattern B:");
for (i = num; i >= 1; i--) {

for (j = 1; j <= i; j++) System.out.print(j + " ");
System.out.println();

} 
System.out.println();
System.out.println("Pattern C:");
for (i = 1; i <= num; i++) {

for (j = num; j >= 1; j--) {

if (j > i) System.out.print("*" + "*");    ///// The issue was you  had to print 2 spaces instead of 1
else System.out.print(j + " ");

}

System.out.println();

}

System.out.println();
System.out.println("Pattern D:");
for (i = 0; i < num; i++) {

for (j = 1 - i; j <= num - i; j++) {

if (j < 1) System.out.print("*" + "*");    //////The issue was you  had to print 2 spaces instead of 1
else System.out.print(j + " ");

}

System.out.println();

}

}

}