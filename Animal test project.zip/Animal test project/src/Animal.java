
public class Animal {  	 	 
	
	public void makeNoise() {  	 	 	
		
		System.out.println("talk"); 
 	 	 	
	}//end method makeNoise 
}//end class Animal 

