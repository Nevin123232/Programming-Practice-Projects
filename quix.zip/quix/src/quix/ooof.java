package quix;

import java.util.*;

public class ooof {

	public static void main (String[] args) {
		
		
		
		
		char[] charArray = new char[26];
	
	

		


			
				
				int[] scores = {1, 20, 30, 40, 50}; 
				System.out.println(java.util.Arrays.toString(scores));

				
			

		
	}
}
