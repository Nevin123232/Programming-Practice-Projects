import java.util.regex.*; 
import java.io.*; 
public class AnswerKeyProblem { 
	public static void main(String args[]) throws IOException { 
		//read in the file provided by your teacher 
		BufferedReader codedAnswers = new BufferedReader(new FileReader("CodedAnswerKey")); 
		//initialize String line as the first line of the file
		String line = codedAnswers.readLine(); //initialize the string answers as an empty string
		String answers = ""; //keep reading each line and adding answers that match answer 
		//possibilities to string answers until there are no more lines in
		//the file
		while(line!=null){ if(line.matches("[a-fA-F]"))
			answers+=line;//add it to the list of answers 
		}//if line is one of the answers 
		
		//read the next line of the file 
		line=codedAnswers.readLine(); 
		
		}//endwhile System.out.println(answers); }//end method main 
		}//end class AnswerKeyProblem
	
