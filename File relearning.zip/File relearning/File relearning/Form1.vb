﻿
Imports System.IO ' I guess this is for writing the file like in the text book
Imports System.Text ' oop 
Public Class Form1
    Private Sub btnwrite_Click(sender As Object, e As EventArgs) Handles btnwrite.Click


        Dim filename As String = "C:\Users\Nevin Ndonwi\Documents\textfilepractice.txt"
        Dim outfile As New IO.StreamWriter(filename)

        outfile.Write(txtinput.Text)
        MsgBox("The file has been found and the text had been inputted ")

        outfile.Close()


    End Sub
End Class
