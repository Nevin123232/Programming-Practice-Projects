


import java.util.Date;

/**
 *
 * @author P
 */
public class GeometricObj {
    //attributes
    private String color="white";
    private boolean filled;
    private Date dateCreated;
    //constructor
    public GeometricObj(){
        dateCreated=new Date();
    }
    //method overloading
    public GeometricObj(String color,boolean filled){
        this.color=color;
        this.filled=filled;
        dateCreated=new Date();
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public boolean isFilled() {
        return filled;
    }

    public void setFilled(boolean filled) {
        this.filled = filled;
    }

    public Date getDateCreated() {
        return dateCreated;
    }
    
}
