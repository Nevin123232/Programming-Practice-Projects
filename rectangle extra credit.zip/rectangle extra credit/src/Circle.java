

/**
 *
 * is-a relationship between super class and subclass
 */
public class Circle extends GeometricObj{
    //attribute
    private double radius;
    
    public Circle(){
        
    }
    public Circle(double radius){
        this.radius=radius;
    }
    public Circle(double radius, String color, boolean filled){
        this.radius=radius;
        this.setColor(color);
        this.setFilled(filled);
    }

    public double getRadius() {
        return radius;
    }

    public void setRadius(double radius) {
        this.radius = radius;
    }
    //functional method
    public double getArea(){
        return Math.PI*Math.pow(radius, 2);
    }
    
}
