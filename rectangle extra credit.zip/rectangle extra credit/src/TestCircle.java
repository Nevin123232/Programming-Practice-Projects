/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author P
 */
public class TestCircle {
    public static void main(String[] args) {
        //instantiate Circle class
        Circle c=new Circle(2.5);
        System.out.println("Date created: "+c.getDateCreated());
        System.out.println("Circle color: "+c.getColor());
        System.out.println("Circle filled: "+c.isFilled());
        System.out.println("Circle area:"+c.getArea());
        
        
        
    }
}
