/*
 * Complete the Rectangel class
 * Retangle has width and height fields
 * Create 3 constructors: 
 * (1)empty constructor, 
 * (2)constructor that takes width and height params,
 * (3)constructor that takes width, height, color and filled as params
 * Create getters/setters for width and height
 * Create a functional method to calculate Rectangle's area
 * Create a functional method to calculate Rectangle's parameter
 * Test Rectangle and print width, height, parameter, area, color and filled
 */
  
 


//Programmer: Nevin Ndonwi
 
public class Rectangle extends GeometricObj {
	
	//rectangle properties
	private int height = 1; // height property initialization 
	private int width = 1; // width property initialization

	
	
	public Rectangle() {
		
		
		
	}
	public Rectangle(int h, int w) { // height and width parameters
		this.height = h;
		this.width = w;
		
	}
	public Rectangle(int h, int w, String c, boolean f) { // height and width and color and filled variable parameters
		super(c,f);
		this.height = h;
		this.width = w;
		
	} 
	
	
	public int getWidth() {
		
		return this.width;
		
	}
	public int getHeight() {
		
		return this.height;
	}
	
	public double getArea() {
		
		return this.width * this.height;
	}

	public double getPerimeter() {
		
		return (2 *(this.width)) + (2 * (this.height));
		
	}
	
	public void output() { //outputs information about the rectangle
		
		System.out.println("A rectangle has been created\nHeight: " + this.height + "\nWidth: " + this.width + "\nArea: " + this.getArea() + "\nPerimeter: " + this.getPerimeter()  + "\nColor: "  + super.getColor() + "\nFilled: " + super.isFilled()  );                            
		
	}
    
	 
	
}

	// class test used to test the functionality of rectangle class
 
	/*
public static void main(String[] args) {
	
	Rectangle x = new Rectangle();
	Rectangle y = new Rectangle(100,400);
	Rectangle z = new Rectangle(200,300,"red", true);
	
	System.out.println("X:   " + x.getColor());
	System.out.println("Z:   " + z.getColor());
	System.out.println("Y:   " + y.isFilled());
	System.out.println("Z:   " + z.isFilled());
	
	x.output();
	y.output();
	x.output();
}
}

*/

